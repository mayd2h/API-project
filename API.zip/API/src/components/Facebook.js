import React,  {Component}from 'react'; 
import {Facebook}from 'fb'; 

export default class Example extends Component {

  options =  {
    appId:'2292165704137137', 
    autoLogAppEvents:true, 
    xfbml:true, 
    version:'v3.2'
  }

  fb = new Facebook(this.options); 

  accessToken = ""

  loginUrl = this.fb.getLoginUrl( {
    scope:['user_friends', 'user_birthday','user_posts','user_gender','user_likes','manage_pages'],
    redirect_uri:'https://localhost:3000/',
response_type:'token'
})





// $loginUrl = new FacebookRedirectLoginHelper($myLoginUrl)->getLoginUrl(['manage_pages']);



getUserData = () =>  {
  this.fb.api("me",  {fields:['id', 'name', 'birthday','friends','gender','likes','posts'], access_token:this.accessToken}, (resp) =>  {

      console.log(resp)
      

  }); 
}
getPageData = () =>{
this.fb.api("me/accounts", {fields:['pages_show_list'], access_token:this.accessToken}, (resp) => {
    console.log(resp);

});

}
// getSinglePageData = () =>{
//     this.fb.api("/256795275016816", {fields:['new_like_count'], access_token:this.accessToken}, (resp) => {
//         console.log(resp);
    
//     });
// }
getSinglePageData = () =>{
  this.fb.api("/256795275016816/posts", {fields:['shares','likes.summary(true)','comments.summary(true)'], access_token:this.accessToken}, (resp) => {
      console.log(resp);
  
  });
}
getPPostPageData = () =>{
  this.fb.api("/323776455161383", {edges:['posts','cover','likes','locations'], access_token:this.accessToken}, (resp) => {
      console.log(resp);
  
  });
}
// hometown
getTryPageData = () =>{
this.fb.api('/256795275016816?fields=about,albums{link},photos{link},phone,location,single_line_address',{access_token:this.accessToken}, (page) => {
    console.log(page);
});
}
  render() {
    // FB.getLoginStatus(function(response) {
    //     if (response.status === 'connected') {
    //       var accessToken = response.authResponse.accessToken;
    //     } 
    //   } );

    if (window.location.hash !== "") {
      this.accessToken = window.location.hash.split("&")[0].split("#access_token=")[1]; 
    }

    if (window.location.hash === "") {
      return ( < a href =  {this.loginUrl} > Login With Facebook </a > ); 
    }else {
      return ( 
      <div>
        < button onClick =  {this.getUserData} > get User Data </button >
        < button onClick =  {this.getPageData} > get Page Data </button >
        < button onClick =  {this.getSinglePageData} > get PageSingle Data </button >
        </div> 
        ); 
    }

   
  }
}