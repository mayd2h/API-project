import React, { Component } from 'react';
import './App.css';
import Facebook from './components/Facebook'
class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <Facebook/>
        </header>
      </div>
    );
  }
}

export default App;
