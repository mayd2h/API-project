things i have done so far
Facebook
** able to fetch
    --- page likes
    --- posts
        -number of post likes
        -number of post comments
    --- The number of people who have liked the Page, since the last login.
*** all the output are displayed on console
plan for this week 
*Facebook* 
--fetch posts with greater likes
--viewing all the information in a table
--classifying the information by week,month,day
*Instagram*
--being able to fetch infos from instagram
--viewing all the information in a table
--classifying the information by week,month,day
